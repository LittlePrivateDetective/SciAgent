"""Agent 状态定义与 Prompt 集中管理。

Prompt 全部集中在此，而不是散落在各节点里——这是评测"Prompt 工程规范性"时
可以直接展示的证据，也方便做 A/B 对比提示词版本。
"""
from __future__ import annotations

from typing import Any

from app.agents.state import SciState  # noqa: F401  统一从 state 模块导出，供图装配使用

__all__ = ["SciState"]


SYSTEM_CONTRACT = """你是 SciAgent 的 {role}。
硬性规则（违反即视为失败）：
1. 只能依据【证据】中的内容作答，不得使用任何外部知识。
2. 引用格式固定为 [编号]，编号必须来自【证据】列表，不允许自己编号。
3. 数字、单位、人名、机构名必须与证据原文一致，不得四舍五入或改写。
4. 回答用简体中文，专业术语保留英文原词（如 multi-head attention）。
5. 不要输出与问题无关的寒暄。
6. 证据能直接回答时必须明确回答，不得用"可能/大概/未明确说明"回避；
   只有通读整段证据后确实找不到，才写"文献中未提及"。"""


PLANNER_PROMPT = """把用户的研究任务拆成 2-5 个可执行步骤。

可用步骤类型：
- retrieve：检索证据（必须，且最多出现 1 次）
- answer：依据证据作答
- compare：多篇对比作答
- verify：引用校验
- reflect：复盘写经验

历史经验（同类任务踩过的坑，必须参考）：
{lessons}

用户任务：{goal}
任务模式：{mode}
可用文献数：{doc_count}

只输出 JSON：
{{"steps": [{{"type": "retrieve", "query": "改写后的检索式"}}, {{"type": "answer"}}],
  "reasoning": "一句话说明为什么这么拆"}}"""


ANSWER_PROMPT = """【证据】
{evidence}

【问题】
{question}

要求：
- 证据由 PDF 切块而来，可能从半句开始（如 "ence pairs containing…"）；请通读整段，
  并优先看每条证据下方的「▸ 关键句」，不要只看开头就判定"未提及"。
- 第一句直接给结论（能一句话答完就一句话），不要写"根据提供的证据…""受证据限制…"这类前言。
- 问「是多少 / 多大 / 几个 / 什么规模」时：证据里出现数值或符号表达式，第一句必须原样给出
  （例如 `O(n²·d)`、`512`、`8 个`）；证据里确实没有，就直说"证据未给出具体数值"。
  既不要用"与…相当""取决于…"含糊带过，也不要自己推算一个填上——后者比含糊更严重。
- 证据里**并列列出**的技术、条件、步骤、指标要全部列出，不要只挑前两项；
  列举不全比多写一句更丢分。
- 结论后面用 1-3 个要点给依据，每点末尾必须带 [编号]。
- 证据充分时就要确定地回答，不要用"可能/大概/未明确说明"来对冲；只有通读全部证据后确实没有的信息，才写一句"文献中未提及 X"。
- 涉及数字/超参/型号时，原样抄写证据中的写法（包括单位），不做换算或四舍五入。
- 全文控制在 300 字以内，不要罗列与问题无关的证据。

输出 JSON：
{{"answer": "正文（含 [1] 这样的引用标记）", "confidence": "high|medium|low",
 "missing": "证据中缺失的关键信息，没有就留空"}}"""


COMPARE_PROMPT = """【证据（来自多篇文献）】
{evidence}

【对比任务】
{question}

要求：
- 用 Markdown 表格做逐项对比（维度｜各文献的做法），表格后给一段结论。
- 每个单元格里的论断都要带 [编号]。
- 明确指出"承袭关系/差异点/演进方向"，这是对比类问题的评分重点。

输出 JSON：
{{"answer": "Markdown 正文", "confidence": "high|medium|low", "missing": ""}}"""


REVIEW_PROMPT = """你是严格的审稿人。检查下面这段回答：
1. 是否有结论而无证据支撑；
2. 引用编号是否与证据表一致；
3. 是否存在"可能/大概/通常"这类含糊表述却给出确定结论。

【回答】
{answer}

【证据清单】
{evidence}

只输出 JSON：
{{"issues": ["问题1", "问题2"], "score": 0-100, "fixed_answer": "若问题严重，给出修订版；否则留空"}}"""


REFLECT_PROMPT = """复盘这次任务，抽出一条可复用的经验。

任务：{goal}
执行轨迹：{trace}
校验结果：{verify}
是否重试：{retries}

只输出 JSON：
{{"scene": "任务类型，如 qa/compare/去重",
  "error_type": "失败类型，如 检索不到/引用越界/答非所问/无",
  "action": "下次应该怎么做，一句话，可执行"}}"""


def render(template: str, **kwargs: Any) -> str:
    safe = {k: (v if v is not None else "") for k, v in kwargs.items()}
    return template.format(**safe)
