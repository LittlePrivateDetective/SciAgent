# SciAgent QA 缺陷与修复记录

> 分级：P0=数据丢失/核心承诺失效/崩溃级；P1=功能缺失或可观测错误；P2=测试台或交互细节。
> 「回归结果」列引用 `03_regression.md` 中的用例编号，具体 PASS/FAIL 以最后一次
> `docs/qa/evidence/latest.json` 为准，不在本文件预填结论。

## 第一轮实测（2026-11-11 11:37–11:46，29 条：PASS 15 / FAIL 8 / BLOCKED 6）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-01 | **P0** | 库内文献从 37 篇 / 19,766 块掉到 30 篇 / 12,656 块，7 篇、7,110 块丢失。日志 `data/logs/sciagent.log` 11:20:59–11:21:06 连续 7 条「已删除文档」 | `DELETE /api/documents/{id}` 直接物理删 chunks/sections/citations/document，**前端删除按钮无二次确认、无审计、无回收站**；一次误触不可逆 | 新增 `TrashEntry` / `AuditLog` 两表；`delete_document` 先写可恢复快照与审计；新增 `/api/documents/trash`、`/{id}/restore`、`/api/audit`；前端改 `ElMessageBox.confirm` 二次确认 + 回收站弹窗与恢复按钮；源文件始终保留在 `data/pdf` | C10；数据恢复见 `evidence/rescan_result.json`（39 篇扫描，6 篇重入库，0 失败）与 `restore_scanned.log`（两份都留流程），最终 37 篇 / 19,766 块 |
| D-02 | **P0** | A04 随机 10 条引用只有 **4/10** 能回原文核对（bbox 内 12-gram 覆盖率 ≥0.5）；典型证据 `text_len=999` 而 `bbox_chars=400` | `_stitch()` 把同页前后邻块文本**拼进 `h.text`**，但 `h.bbox` 仍是主块矩形——证据文本与锚点不再一一对应，点锚点看到的只是证据的一部分，直接违反「细粒度精准出处」 | `_stitch` 重写为**邻块独立 Hit**：同页紧邻后一块作为独立证据条目，带自己的 `chunk_id/bbox/anchor/neighbor_of`，主块 `text` 不再被改写；命中数 8→9，`to_dict` 增加 `neighbor_of` | A03（锚点全部独立）、A04（溯源命中率）；C07（流式结果同样带完整 evidence） |
| D-03 | **P0** | A01 复杂对比问题耗时 85.1s，最终答案是「原回答只是系统错误提示…无法在现有证据基础上修订」这类**元话语**，不是问题答案 | ① `deepseek-v4.1-flash` 是推理模型，JSON 包裹 + 长对比表格把 4096 输出预算吃光，`writer` 连续两次返回空串；② 兜底文案进入 `node_review`，审稿 Agent 把它当正文改写 | ① 新增第三次兜底：换非推理模型 `qwen-flash` 写**纯文本**答案（不套 JSON），预算 3000；② `node_review` 在上游 `error` / 文案过短 / 命中「模型未返回、系统错误」等元话语时**直接短路**，不再加工降级文案；③ `node_answer` 增加 `writer.route` 步骤记录 `mode/template/evidence_docs`，让路由可观测 | A01、A02 |
| D-04 | P1 | A06 / C07 / C09 / B02 / B05 全部 404；官方要求的 Function Calling、Token 流式、CSV 转 TikZ/Mermaid、Future Work 提炼、GitHub 复现性均无实现 | 上一阶段只完成解析/RAG/图谱/对照阅读，未按评分细则补齐工具层与科研增强 | 新增 `app/tools/external.py`（arXiv / GitHub / Crossref，OpenAI tools schema，`decide()` 用 LLM 真实选工具，重试→外部 API→本地库降级且带 `degraded` 标记）、`app/tools/chart.py`（无损数值搬运到 Mermaid/TikZ）、`app/research/future_work.py`（触发词候选句→4-gram 去重→关键词对撞）、`app/research/reproducibility.py`（GitHub REST 真实数据加权分级）、`/api/chat/stream` SSE + 前端思考时间线与逐 token 渲染 | A06 / A06B / A06C / B02 / B05 / C09 / C07 / C07B |
| D-05 | P1 | C08 中「不存在的文档」返回 **200 + 空列表** | `get_chunks` / `get_sections` / `get_references` 未校验 doc_id 是否存在 | 三个接口先 `db.get(Document, doc_id)`，不存在即 404；测试台同步收紧断言 | C08 |
| D-06 | P1 | F01 缺 `LICENSE`；README 写 Apache-2.0 与代码不一致 | 交付要素未闭环 | 新增 MIT `LICENSE`，README 许可证段同步为 MIT，并补齐新接口/QA/已知限制说明 | F01 |
| D-07 | P1 | E03 静态检查发现 `requirements.txt` 缺 `chromadb`：容器会静默退化成 SQLite+NumPy，与实测 Chroma 环境不一致 | 只在本机 venv 装过 chromadb，没回写依赖清单 | requirements 补 `chromadb>=0.5.0`；`.env.example` 补 `TRANS_*` 四项；Dockerfile 保持通过 compose 注入 `.env` | E03（docker build 本机仍【待实测】）、C03（干净环境等价复现） |
| D-08 | P2 | A01/A02/A03/B01 四条用例自身报错或断言不合理（`plan` vs 实际 `planner`；`retrieve` 函数不存在；`build_graph()` 缺 db 参数；要求两种模式 agent 序列必须不同） | 测试台按想象写断言，没先核对真实接口契约 | 全部改为核对真实契约：A03 改 `search_with_rerank` 并检查 `dense_score/sparse_score/anchor` 独立性；B01 用测试台内**纯 NumPy 独立幂迭代**复算 PageRank 与入度；A01 增加元话语检测；A02 改为核对 `writer.route.template` 与答案形态 | 对应编号用例 |
| D-09 | P2 | A05 报「无扫描件；长文档解析异常」 | 由 D-01 的数据丢失连带造成，不是解析代码 bug | 恢复 7 篇文献；扫描件因与 v1 同族被 rescan 判重，改走产品自带「上传→判重→两份都留」真实流程入库（`tests/restore_scanned.py`，193 秒，OCR 后 `is_scanned=true`） | A05、C04 |
| D-10 | P2 | C01「并发导入」实际只传 2 份、全部被判重，0.8 秒结束，没走解析/向量化 | 用例用 `data/uploads` 里的重复副本，且只检查 HTTP 200 | 改为用 PyMuPDF 从 3 篇不同论文各取前 2 页生成**互不相同**的探针 PDF，真正并发入库，再逐篇抽查首页块是否串档，测完移入回收站 | C01 |
| D-11 | P2 | B04「库内无多版本文献」无法测 | 用例假设库里存在 `version>1`，实际同族版本被判重后未入库 | 改为上传 `1706.03762v7.pdf` 触发**真实 v1↔v7 判重**，核对返回的章节/句子级差异报告，再调 `/diff` 接口 | B04 |

## 第二轮实测中新发现

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-12 | P2 | `round2_targeted.log`：A06 报「外部工具调用失败 HTTP 200」，返回体 `error=参数不匹配` | ① 用例按旧约定把 `query` 平铺在 body，而 `ToolIn` 要求 `args` 字典；② 路由 `{"ok": True, **ToolResult}` 中 ToolResult 自带的 `ok` **覆盖了** HTTP 层 ok，产生歧义结构 | `tools_invoke` 直接返回 `ToolResult`（自带 ok/degraded/source/attempts）；A06 改用本机可达的 GitHub API 做成功路径、arXiv 做诚实降级路径 | A06 / A06B / A06C |
| D-13 | P2 | B03 三层去重只命中同族与标题，SimHash 层未命中 | 用例把 `v9` 直接拼在 `v1` 后面（`1706.03762v1v9`），且用**前 60 个 chunk** 当 full_text，与入库时 `parsed.body_text()` 的指纹不同 | 用例改为 `parse_pdf` 重新解析得到真实 `body_text()`，验证 `content_hash/simhash` 与库内一致，再用「全文 + 一句附录」构造近似文本；同族用正则替换版本号 | B03 |
| D-14 | **P1** | C07B「未找到发送按钮」；`dump-dom` 显示 `.ask-bar` 里**只有 el-input，没有发送按钮**——界面从上线起就缺按钮，用户只能按回车 | Vue 模板写在 HTML 里，**自定义元素不能自闭合**：`<el-input ... />` 被浏览器解析成开始标签，后面的 `<el-button>发送</el-button>` 被吞进 el-input 的默认插槽，而 el-input 不渲染默认插槽。同类问题还有 2 个 `el-option`（「全部文献」选项被吞）、2 个 `el-switch`（联动/整篇翻译按钮被吞）、`el-checkbox` | 6 处全部改成显式闭合标签；`dump-dom` 复核：`el-button--primary` ×2、`发送</span>` ×1、`全部文献` ×1、`流式`/`回收站` 均在 | C07B、界面截图 `evidence/ui_main.png` |
| D-15 | P2 | `restore_document` 重新解析后生成**新的 doc_id**，但返回体没带回，前端/QA 拿旧 id 查询会 404 | 恢复走 `ingest(force=True)`，主键重新生成 | 返回体增加 `doc_id` / `old_doc_id`；C10 按新 id 复核块数并清理探针 | C10 |
| D-16 | P2 | C07B 在虚拟时钟 45s 预算下只输出 `running…` | 流式请求是真实网络，无头浏览器的 virtual-time-budget 在等待网络时不足以跑完 ready 轮询 | stream 类型预算提到 120s、子进程超时 260s；QA 页在点击发送后立刻写一条进度日志，便于超时定位 | C07B |

## 第三轮实测中新发现（2026-11-11 14:00–14:30）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-17 | **P0** | A04 溯源修到 9/10 后，剩下 1 条扫描件证据 `evidence=589 字` 而锚点原文 `508 字`，差 81 字 | `_stitch()` 追加**邻块独立证据**时直接取 `Chunk.text` 原始值，开头带着 80 字 overlap；主检索通道已统一剥离，邻块路径漏了 | `_stitch` 一次查出主块+邻块，以主块**原始**文本为 prev 调 `strip_carry(main_raw, text)` | A04 **10/10**（`run_20261111_142756.json`）、A03、C07 校验 6/6 |
| D-18 | **P1** | 第二轮 A04 只有 **1/10**：普通 PDF 证据文本普遍比 bbox 内原文多 80 字 | `Chunk.text` 是带 overlap 的分块文本，但 `bbox` 只覆盖本块。首轮只修了 `_stitch` 拼接，没修语料加载本身 | 新增公共 `app/rag/chunker.strip_carry()`，在 `_load_corpus` 按文档顺序逐行剥离；`bilingual.py` 删重复实现改为复用 | A04 1/10→9/10→10/10；B06 对照阅读无重影 |
| D-19 | **P1** | B03 SimHash 层不命中：全文加两句附录，指纹翻转 **38 位**（阈值 6） | `simhash64()` 拿 `normalize(text)` 分词，而它把空格全删，36k 字变成 1 个巨型 token，整张指纹由一个 md5 决定 | 保留词边界，只在数字/标点层归一化，并加词频加权 | 加 1–2 句距离 0–1、删 10% 距离 3、完全不同 32；B03 PASS |
| D-20 | **P1** | A05 扫描件 `refs=0`，但 OCR 文本 p10–p12 含完整 `[1]–[36]` References 区 | `finalize_ocr_structure` 只认裸标题行，OCR 把章节号与 References 粘连（`10 References`）且条目是数字编号 | 放宽 OCR 参考区识别并按行序还原；写 `scripts/repair_corpus.py` 修补**已入库数据** | 扫描件补建 **35 条**参考文献；全库 simhash 37 篇重算；A05 PASS |
| D-21 | **P1** | 容器静态校验：`langgraph`（本机 1.2.20、编排核心）**未声明**；另有 5 个包被声明但代码从不 import | 依赖清单是早期规划遗留。容器里不装 langgraph 会让 `build_langgraph()` 静默降级成手写状态机 | 重写 `requirements.txt`：补 `langgraph>=0.2`/`PyYAML`，删 5 个冗余包并逐条注明理由；OCR 与本地向量档标为可选 | E03：15 个第三方 import 全部声明、零密钥布局启动 5 接口全 200 |
| D-22 | P2 | C07B 虚拟时钟 120s 下只输出「开始真实 SSE…」一行，连 catch 都不进 | 虚拟时钟快进 `setTimeout`，但 SSE 的 `reader.read()` 是真实网络 I/O，Promise 永不 resolve。后端 SSE 实测 116 行/2.5s 正常 | 新增 `tests/browser_cdp.py`：websocket-client 连 CDP 在**真实时间**驱动、轮询 `#out` 并截图；加 `--remote-allow-origins=*` 解决握手 403 | C07B PASS（思考步骤 4、DOM 315 字、证据 11 条），截图 `evidence/ui_stream_20261111_140650.png` |
| D-23 | P2 | A04 用例自身抛 `NameError: name 'Chunk' is not defined` | 改写判据时新增 `db.get(Chunk, ...)` 与 `select(...)` 却漏加导入 | 补 `from sqlalchemy import select` / `from app.db.models import Chunk, Document` | A04 正常执行 |
| D-24 | P2 | E03 预演触发批量删除保护（8991 文件）；随后 `UnboundLocalError: os` | 预演用 `shutil.rmtree` 清旧目录；函数内残留 `import os` 让整个函数的 `os` 变成未绑定局部变量 | 改时间戳独立目录不删旧（预演产物本身就是证据）；删除重复局部导入 | E03 PASS，48–60 秒 |
| D-25 | P2 | A06 断言字段错位、C11 把昨天的历史 Traceback 算作本轮崩溃、C10/C01 探针被判重形成"假 PASS"、A05 判据过严 | 测试台按想象写断言 / 扫了全量日志 / 用重复副本做并发探针 | A06 改按 `source/degraded` 判断且 GitHub 作成功路径；C11 只扫本轮时间窗；C01/C10 用 PyMuPDF 生成不同论文前 2 页探针并走「两份都留」强制入库 | A06/C11/C01/C10/A05 全部 PASS |
| D-26 | P1 | A02 两种模式的 `writer.route.template` 都是 `compare`，路由未分化 | 用例用含"对比"的问题同时测 qa/compare，而产品按**意图优先**设计，属用例构造与产品意图冲突 | 产品侧把决策依据（`default`/`explicit_mode`/`intent_hint`/`evidence_docs`）写进 trace；用例改用不含对比词的 qa 问题 | A02 PASS：`qa→qa(default)` / `compare→compare(explicit_mode)` |
| D-27 | **P1** | 交付轮 C06 报 `RSS 7→7 MB`，而同样环境前两轮是 820 MB / 1031 MB——数字明显失真却判了 PASS | 用例按 `cmdline` 关键字遍历取**第一个**匹配的 uvicorn 进程，抓到了 C03/E03 刚拉起、还没加载语料的子进程；且没有合理性断言，任何读数都算通过 | 改为按**监听 8013 端口**的 PID 定位主服务，兜底时取 RSS 最大者；并加 `before < 150 MB → FAIL` 断言（主服务加载 Chroma + 19,766 块，不可能只有几十 MB） | C06 复测 **PASS：RSS 629→630 MB（Δ+0.6 MB）**、GPU 1020 MiB；`latest.json` 只允许全量运行写入，避免定向回归覆盖 |
| D-28 | P2 | C07 流式答案的 `bad_numbers=['12']`（引用校验 12/13），但核对论文 p2 原文确有 `twelve hours`、p7 写作 `12 hours` | 数字溯源按**字面**比对阿拉伯数字，英文数词 `twelve` 不在证据池里；答案引 p2 写「12 小时」语义正确却被误标未核实。属安全侧误报，会降低评委对校验器可信度的判断 | 新增 `_WORD_NUM` 英文数词表，只把证据文本里的数词**加进证据池**，不放宽答案侧 | 单元级正反验证：正例 `12` 放行（rate 1.0）、编造 `99/77` 仍被拦（bad=['99','77']）；交付轮 C07 回归 |
| D-29 | **P1** | `Dockerfile` 的 `COPY docs ./docs` 会把 `docs/qa/evidence/` 下 582 MB 的浏览器 profile 与截图缓存打进镜像；容器预演递归复制后 `data/_qa_container_*` 膨胀到单个 584 MB | 缺 `.dockerignore`；预演脚本复制 `docs` 时也没排除证据目录 | 新增 `.dockerignore`（排除 `data/`、`tests/`、`docs/qa/evidence/`、`.env` 等）；预演复制与忽略规则保持一致；`.gitignore` 补浏览器 profile 与 `_qa_*` 临时目录 | 交付轮 E03（预演 91s→提速）、F01；证据本体仅 1.3 MB 入库 |
| D-30 | **P1** | 用户实测截图指出「全部文献」下拉与「问答/对比」按钮没对齐。用 `tests/ui_layout_check.py` 量出：三控件高度都是 24px，但**中心线极差 3.25px**（下拉与开关 75.88，按钮组 79.13） | `.chat-tools` 在 CSS 里**完全没有定义**，三个 Element Plus 控件按 inline 基线排列，各自的行盒高度不同 → 基线对齐而非中线对齐；`panel-head` 又只用 `space-between`，宽度紧张时控件被压缩 | 新增 `.chat-tools/.viewer-tools { display:flex; align-items:center; gap:6px }`；面板头统一 44px、控件统一 24px 视觉高度；标题 `flex:none` 不再被压缩；右栏 1280 断点 320→360px，≤1100px 头部自动换行 | `layout_v3_{1680,1280,1100}.json`：**中心线极差 3.25px → 0px**，无溢出，标题宽度 52px 未被截断；B06/B07/C05/C07B 四项 UI 回归全 PASS |
| D-31 | **P1** | 对话区证据列表的序号徽标被 flex 压缩，`[1]` 被拆成「`[` `1` `]`」三行，第 10 条更是「`1` `0`」竖排；文档名被截到只剩 `1706.03…`，v1 与 v1_img 两篇无法区分 | `.evid-idx` 没有 `flex:none/nowrap`；`.evid-doc` 用 `flex-basis:auto`，与摘要按内容比例抢宽度 | 序号设 `flex:none`+`tabular-nums`，页码单独成列且不可压缩，文档名固定 `flex:0 0 40%` 并加 `title` 悬浮全名；摘要 `flex:1 1 0` 省略号截断；证据区限高 196px 独立滚动 | `shot_evid.png`：`[1]…[10]` 全部单行，页码/文档名/摘要四段清晰；C07B PASS |
| D-32 | **P1** | 宽 markdown 表格在 360px 右栏被压成「一字一行」的竖排（截图 `shot_chat3.png` 把 `1706.03762v1_img.pdf` 竖排成一列字符） | `mdToHtml` 生成的表格套 `width:100%`，6 列在 360px 内每列只剩 50 余像素；`word-break:break-word` 允许逐字断行 | 生成时给表格包一层 `.md-table-wrap`（`overflow-x:auto`），表格改 `width:max-content` + 单元格 `min-width:64px`，横向滚动而非挤压 | `shot_chat4.png`：4 列表格横向正常排列、可滚动；答案正文与锚点徽标排版正常 |
| D-33 | P2 | 文献列表复选框随行高垂直居中，两行标题时复选框飘到第二行旁边；删除按钮 37 行常驻红字，视觉噪音大 | `.doc-item { align-items:center }`；删除按钮无显隐控制 | 列表改顶部对齐（复选框对齐标题首行）；删除按钮改 hover 淡入（触屏保持低透明度常显）；空状态问题样本改为可点卡片 + 悬挂缩进 | `shot_doclist2.png`、`shot_samples2.png`；列表与空状态整齐 |
| D-34 | **P0（能力缺失）** | 官方 1.3.2「点正文 [11] 跳到 References」与 1.3.3.1「划词翻译」都无法实现：阅读器是 PNG 页图，正文是像素，既不可选也不可点。后端 `/refs` 只返回引用边，前端从未调用 | 架构取舍遗留：页图渲染换来了排版 100% 还原，代价是丢掉文本层 | 新增 `/documents/{id}/page/{n}/text` 返回**词级 bbox**，前端在其上叠一层 `color:transparent` 的绝对定位文字；整层按 PDF 原始 pt 布局、整体 `transform:scale` 缩放到图片宽度；新增 `/documents/{id}/references`（编号→页码+bbox）与 `POST /translate` | B08：文本层与页图对齐误差 **0px**、100% 词落在页面内；B09 划词返回「注意力机制已成为不可或缺的一部分」 |
| D-35 | **P1** | 点正文 `[29]` 跳转后，高亮框只有 **1.14% 宽、2px 高**，几乎不可见（实测 `hlInline: "left:0.163%; top:0%; width:1.14379%"`） | `/references` 把数据库里的 `"108,554.9,505.2,586.7"` **字符串**原样返回，前端 `const [x0,y0,x1,y1] = bbox` 对字符串逐字符解构，拿到 `"1","0","8",","` | 后端返回前 `split(",")` 转 float 数组（与 `/chat` 的 evidence 契约统一）；前端 `boxStyle` 再加一层归一化，非有限值直接 `display:none` | B08：`hlBox` 变为 `[108,554.9,505.2,586.7]`，高亮 **628×50px**（占页宽 65%），截图 `tl_cite.png` 精确圈住 [29] 整条 |
| D-36 | **P1** | 跳转到 References 后目标条目在滚动区域之外，用户看不到高亮，以为跳转失败（截图 `tl_cite.png` 只显示到 [26]，而 [29] 在 y=554.9） | `jump()` 里用 `stage.scrollIntoView()` 只把阅读区滚进视口，没有滚动 `.page-stage` 内部到目标位置 | 用 rect 差值算滚动量：`stage.scrollTo(stage.scrollTop + (hr.top - sr.top) - (clientH - hr.height)/2)` | B08：`scrollTop` 0 → **529**，`hlTopInView` 361（可视高 748），高亮居中 |
| D-37 | P2 | 文本层容器 `getBoundingClientRect()` 宽高均为 **0**（`dw:-968, dh:-1252.7`） | `.text-layer` 绝对定位且子元素也全是绝对定位，没人撑开父级 | 显式绑定 `width/height` = PDF 原始尺寸，仍靠 `transform:scale` 缩放 | B08 geometry：`layerW/H` = `imgW/H` = 968×1252.7，**dw=dh=0** |
| D-38 | **P1** | 划词选中后文本粘连成 `Attentionmechanismshavebecomeanintegralpartof`，译文质量下降且复制粘贴不可用 | 每个词是独立绝对定位 span，之间没有文本节点，`getSelection().toString()` 直接拼接 | 每个 span 渲染 `w.t + ' '` | B09：选区变为 `Attention mechanisms have become an integral part of` |
| D-39 | **P1** | 写作框架偶发**四段全空**：`citations_total:0`、`title` 退回 idea 原文（F04 首次运行实测失败） | 写作走主模型 `deepseek-v4.1-flash`（带思维链），`max_tokens=3000` 被推理过程吃光，正文一字未出。与翻译此前踩的是同一个坑 | 新增 `WRITE_MODEL=qwen-flash`（非推理）+ `WRITE_MAX_TOKENS=6000` | 连跑 3 个不同 idea：**3/3 成功**，7.2s / 9.3s / 23.0s，四段齐全，越界引用 0 |
| D-40 | **P1** | 模型返回 `{}` 时，服务端仍返回 `ok:true` 和四个空段落，前端渲染出一片空白且无任何报错 | `generate()` 只看 `chat_json` 是否抛异常，没校验内容 | 四段全空时显式返回 `ok:false` + 可读错误 | F03 断言覆盖：章节字数 <120 直接判 FAIL |

## 第四轮实测（2026-11-11 19:30–19:45，用户截图反馈：译文浮层挡字）

| D-42 | **P1** | 扫描件页面上按住鼠标想选字，**整张页图被浏览器拖走**（ghost 影像跟着光标跑），用户以为"文档被我拖跑了"（用户截图 + 录屏描述）；同一页划词翻译不可用，界面只有一句「无文本层 · 不可用」，没有任何出路 | ① `<img>` 默认 `draggable=true`，`.pdf-page` 也没写 `-webkit-user-drag`；② 扫描件没有词级文本层（`get_text("words")` 返回空），划词天然不支持，但产品没给替代动作 | ① 页图 `draggable="false"` + `-webkit-user-drag:none; user-select:none`；② 新增 `POST /documents/{id}/page/{n}/translate`：按 `idx` 顺序取该页 chunk，走 `translate_pages` **逐段落库翻译**再拼回（与「对照」视图共用 `translations` 缓存，重复点秒出）；③ 提示条加「翻译本页」按钮，复用划词浮层展示（可拖可滚）；④ 提示条从 `page-frame` 内部移到阅读区外层——挂在页图内时它贴在整页图底部，页图高于视口就永远看不见（本轮实测踩到）；⑤ 左栏「扫描件」徽标补 `title`，说明"图片版 PDF、能检索能对照但页面上不能划词" | `tests/ui_scanned.py`：`draggable=false`、`webkitUserDrag=none`、提示条含「翻译本页」；点击后 **9/9 段译出 1429 字**、浮层标题「整页翻译 · p2」、拖动 (677,104)→(417,364)；`ui_textlayer` 增断言「有文本层的页不得出现扫描提示」；`ui_sel_drag` 仍 PASS |


| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-41 | **P1** | 划词译文浮层固定在选区左上角（实测 `left:463.2, top:226.7`），与选区矩形重叠 **6580 px²**，正好压住正在读的那一行；浮层是 `position:fixed` 的死卡片，**没有任何可抓取区域**，用户只能关掉才能继续读 | 落点由 `getBoundingClientRect()` 一次算死，没有拖拽实现；整块区域都让给了文本内容 | 浮层拆成「标题栏 + 内容区」：28px 标题栏兼作拖动手柄，`pointerdown` 记住按下点相对左上角的偏移，window 级 `pointermove` 跟手（鼠标甩出浮层也不丢帧），边界用 `offsetWidth/offsetHeight` 夹在视口内；拖动全程 `body.is-dragging{user-select:none}` 防止把正文一起刷蓝；内容区 `max-height:46vh` + 常驻细滚动条，长译文框内滚动而不是撑成一屏白块 | `tests/ui_sel_drag.py`：重叠 **6580 → 0**；位移 (−423.2, +420.3) 与鼠标位移**逐像素一致**（`grip_error 0.0px`）；拖动后整框仍在视口内、`dragging`/`bodyLock` 复位、头部 × 正常关闭；1157 字符长选区译出 374 字，框高 426.5px（视口 862）、`bodyClientH 397 ≤ 46vh`、可滚动、不越界 |


## 性能与优化前后对比（均为实测）

| 指标 | 优化前 | 优化后 | 依据 |
| --- | --- | --- | --- |
| 引用溯源准确率 | 4/10（首轮）→ 1/10（第二轮判据收紧后暴露 overlap） | **10/10** | `round1_console.log` / `round2_console.log` / `run_20261111_142756.json` |
| 单次问答（语料缓存前） | 36s | 3s | 上一阶段 `CorpusRow` 轻量缓存，见 `memory/2026-11-11.md` |
| 一页中英翻译 | 20s（qwen-plus 串行） | 3–6s（qwen-flash + 3 路并发） | 上一阶段实测日志 |
| 打开一页自动译完整篇 | 90 段 / 45 秒（无限链预取） | 只译当前页 5 段 | 上一阶段 `bi3.png` + `translations` 表计数 |
| 复杂对比任务 | 85.1s，答案无效（元话语） | 100.8s，答案 3477 字且编排节点齐全 | 第一轮 A01 / 第三轮 A01（耗时仍偏高，已列扣分项） |
| SimHash 近似文本（加 2 句） | 汉明距离 38（漏判） | 0–1（命中，阈值 6） | D-19 实测输出 |
| 长 PDF 页图 | — | 81ms（首屏）/ 页元数据 39ms / 章节树 6ms | C04 |
| 图谱首帧（37 节点） | — | 265ms，canvas 998×678 | C05 |
| 服务 RSS | — | 1031→1030 MB（Δ-0.3 MB）；GPU 915 MiB 为系统占用 | C06 |
| 流式输出 | 无 | 39–53 个 token 片段无损拼接，思考阶段 4 个，前端逐 token 渲染 | C07 / C07B |
| 检索效率 | — | 6,341,691 字 / 19,766 块中 17.5s 定位 11 条证据，过滤 99.909% 语料 | F02 |

## 第五轮：补齐官方 1.4（2026-11-11 20:00–20:55）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-43 | **P1（能力缺失）** | 官方 1.4「论文自动下载和推荐」整块未实现：只能手工上传或一键导入本地测试集，没有任何"按标题下载""按参考文献补全""推荐新论文"的入口 | 上一阶段把外部检索做成了 Agent 的一个工具（`arxiv_search`），服务于问答，没有面向用户的产品化闭环 | 新增 `app/research/discover.py` + 6 个接口 + 前端「发现」抽屉（三 tab）：<br>① 搜索下载：`all:"..."` → `ti:` → `all:` 三级退化检索，标注是否已在库；下载后走**既有 ingest**（去重/解析/切块/向量化/章节树全复用）<br>② 补全参考文献：解析 References 条目 → 匹配 arXiv → **按正文 `[n]` 出现次数排序**，把"为引用而引用"排后面；批量补全走后台 job + 进度轮询<br>③ 新论文推荐：库内 TF-IDF 兴趣画像打分 → 三级检索（AND / OR+2 词命中 / 不限日期）→ 模型逐篇写中文理由 → GitHub 加权 → 赞/踩反馈落库 | `tests/ui_discover.py`：搜索 8 条（其中 1 条正确标注"已在库里"）、参考文献 8 条被引次数严格降序（10→7→6→4→3→2→2→2）且默认勾选 5 条、推荐 6 条理由全部非空、2 条带 GitHub、踩一条后立即从列表消失；真实下载 ELECTRA(2003.10555) 入库 **234 段 / 11.2s** |
| D-44 | **P1** | 自动下载 ELECTRA（2003.10555）后入库被判"内容高度重合"，与实际无关的 BERT（N19-1423.pdf）撞车：`reason=正文指纹近似(汉明距离=6)`、`similarity=0.906` —— 下载成功却入不了库，1.4.1 直接失效 | SimHash 汉明距离 ≤6 一刀切判重。同领域论文大量共用词汇，64 位指纹本来就容易靠近；原实现没有再验标题 | 距离 ≤4 直接判重；5–6 这一档追加标题相似度校验（≥0.6 才判重）。真·同篇不同版本标题几乎一致（>0.9），标题差异大的是两篇不同论文 | 修复后同一篇下载入库成功；QA 原有版本检测用例（v1/v7 同族、正文相同）仍走 `family_key` / `content_hash` 分支，不受影响 |

## 第六轮：补齐官方 1.6.4 中译英（2026-11-11 20:20–21:00）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-45 | **P1（能力缺失）** | 官方 1.6.4「自动将中文论文的摘要或全文翻译成英文」完全没做：`/translate` 只认英译中，提示词写死「译成中文」；划词逻辑里还有一行 `if (!/[A-Za-z]{2,}/.test(txt)) return;`，**中文选区直接被丢弃**，连选择都不会触发浮层 | 1.3.3 只要求英译中，实现时把方向当成了常量而不是参数 | ① 提示词参数化：新增中译英 `_SYS_EN`（学术英文、术语一致、不外漏汉字、a/an 与数字搭配）；`_translate_batch(texts, to)` 双向；② `detect_lang` 按汉字占比 >18% 判语种，`translate_selection(text, to="")` 自动选方向；③ 整篇中译英 `start_en_job`：按 ~1200 字/批、3 路并发，非中文段落（英文摘要/公式/代码）原样跳过，标题与小节标题一起批量译，产出 `data/exports/{id}_en.md`；④ 前端划词允许中文、浮层标题按方向显示「译成英文」；阅读器工具栏加「译英」+ 抽屉预览/下载 | `tests/ui_translate_en.py`：划词标题=「译成英文」、译文 238 字符、**汉字 0 个**；整篇 1852 字符 / 3.8s、h1 为英文标题、无裸露 `##`、预览汉字 0；后端 curl 实测「an 11-millisecond」冠词正确 |

## 第七轮：证据高亮改为句级精确（2026-11-11 20:40–21:10，用户截图：高亮是一大块，且位置不对）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-46 | **P1** | 点证据后正文被涂成**一整块黄方块**：实测 chunk bbox 高 94.5pt ≈ 7 行，整段（含与该结论无关的句子）全被盖住；用户原话「不要是一个长方形的黄色框，我想精确到句子，句子开头可能在文章中间」。同时因为整段都亮，读者无法判断到底哪一句支撑了结论（截图里的提问是 BLEU 分数，亮的却是另一段） | ① 前端 `.hl` 直接画 `chunk.bbox`——chunk 是段落级单位，一个矩形画不出"句子"；② 检索/答案环节没有记录"哪句在支撑这个论断"，evidence 里只有整段文本 | ① 新增 `app/rag/focus.py`：保守拆句（处理 e.g./Fig./J. 等缩写）→ 按问题实词、答案实词、**答案中的数字**加权打分（数字权重 3.0，因为"BLEU 是多少"的答案句靠 28.4 就能锁定）→ 取 1–2 句；`/chat` 与 `/chat/stream` 都在返回前给 evidence 补 `focus` / `focus_mode`；② 前端改用**词级文本层**还原几何：只在 chunk bbox 内取词 → 贪心顺序对齐 → 按行聚成多个矩形，句首从行中间起、句末到最后一个词止；③ 无文字时（正文 `p7 ▸` 锚点）按 bbox 内所有词逐行画；④ 扫描件无词级坐标才退回区块框，并改成**虚线 + 更淡**，明确表示"这是近似范围" | 文本版 PDF：**3 个逐行小框**、框高 16.13px vs 行高 15.82px、覆盖关键句 **37/37 词**、框内无关词 **0**、面积 **29.3%**（原 100%）、3 个框全部"句首在行中间"；扫描版按预期 1 个虚线近似框；表格段逐行 **20 框**、面积 21.3%；`ui_textlayer` / `ui_scanned` / `ui_writer` / `ui_discover` 全部仍 PASS |

| D-47 | **P1** | 点答案里的 `p7 ▸` 锚点，跳到的却是**当前正在读的文献**的第 7 页：实测阅读器开着 ViT（2010.11929），点 Transformer 论文答案里的 `p7 ▸`，页面仍停在 ViT，并按同一块坐标涂了一大块黄——用户看到的就是"高亮明显错了、位置也不对" | 锚点字符串只有 `[p7@x0,y0,x1,y1]`，页面格式里没有文献 id；点击处理直接用了 `this.activeDocId`。证据列表走的是 `jump(e)` 带 `doc_id`，所以只有锚点这条路会跑偏 | `evidenceAt(page, bbox)`：按页码 + 坐标（±2pt，服务端锚点做了取整）回查本轮回答的 evidence，取它的 `doc_id` / `text` / `focus` 再 jump；查不到才退回当前文献 | `tests/ui_hl_sentence.py` 第 5 阶段：阅读器先切到 ViT，再点 Transformer 的 `p7 ▸` → `2010.11929v2.pdf` → **`1706.03762v1.pdf` p7**，3 个逐行框、无近似框（框高 16.13px / 行高 15.82px） |

## 第八轮：后台参数控制台（2026-11-11 21:30–22:20）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-48 | **P1** | 新加的后台页 `/admin` 整页白屏：`#app` innerHTML 为空、`window.__admin` 不存在，控制台只有一句 `Script error. @:0`（跨域脚本报错不透露细节） | HTML 里 `<el-input ... />`、`<el-switch ... />` 等自定义元素写成自闭合。浏览器不认非空元素的自闭合斜杠，把它们当"未闭合起始标签"，后续兄弟节点全变成子节点，Vue 编译模板失败；因为 Vue 来自 CDN，异常被浏览器标成跨域 `Script error.`，看不出原因 | 全部自定义元素改显式闭合（17 处）；测试里注入 `window.onerror` 捕获，失败时把异常文本一并输出 | 修后 `#app` 正常挂载、37 项参数渲染、`ui_admin` 全绿 |
| D-49 | **P1** | 点「全部恢复默认」后 `llm_api_key` 变成空串，服务当场失联，必须重启进程才恢复（实测：重置后 `secretSet=false`，模型自测报未配置） | `reset()` 把参数写成"代码里的出厂默认值"，而出厂默认是空字符串；`.env` 里配的 key / 模型名被一起清掉 | 新增 `BOOT_VALUES` 启动快照（本模块在 startup 回灌覆盖之前 import，此刻 settings 全是 .env 值），恢复默认改为回填快照；界面提示同步改成"回到启动时 .env 里的值" | 重置后 `top_k=8`、`source=env`、`secretSet=true`，模型自测仍可正常调用 |
| D-50 | **P2** | 一打开后台就显示"有 1 项未保存"：`ollama_enabled` 明明没动过 | 该字段在 `Settings` 里是 int（0/1，便于环境变量），`describe()` 原样返回 `0`，前端 `el-switch` 给的是布尔 `false`，`JSON.stringify(0) !== JSON.stringify(false)` → 判定为脏；进一步点保存会把 `false` 写进库 | `describe()` 对 bool 类参数统一返回 `bool(value)`，`default` 同样归一；测试增加"打开后脏项数必须为 0"的断言 | `dirty=0`；`ui_admin` 的 base 断言覆盖该项 |
| D-51 | **P2** | 概览页左侧「模型与检索」卡被压成 129px 宽，标题竖排成一个字一行；右侧卡 2731px、溢出容器 1326px | `.grid2` 用 `1.15fr 1fr`，`fr` 轨道以 min-content 为下限；审计卡里一行 `white-space:nowrap` 的操作详情把第二列撑到 2731px | 改为 `minmax(0, 1.15fr) minmax(0, 1fr)` 并给 `.card` 加 `min-width:0`；`.kv` 的第二列同样 `minmax(0,1fr)` | 实测两卡 703 / 611px（差 92px，容器 1326），`ui_admin` 增加布局断言防回归 |

| D-52 | **P1（安全）** | 后台与 `/api/admin/*` 一开始**没有任何鉴权**：同一网段内任何人访问端口就能改 `top_k`、换模型、读参数表（密钥只有掩码但仍能看出配没配、掩码前后 4 位），还能点「全部恢复默认」把线上配置清掉 | 先做功能后补权限，且 `DEMO_ACCESS_TOKEN` 一直是配置项、没有中间件实现 | 新增 `app/core/auth.py`：口令只读环境变量 `ADMIN_PASSWORD`；登录成功签发随机令牌（`HttpOnly` Cookie，12 小时）；所有 `/api/admin/*` 走 `require_admin` 依赖；登录失败按 IP 限速（8 次 / 10 分钟，429）；前端加登录门，任一请求 401 立即退回登录页 | 未登录读参数 **401**、错口令 **401 `口令不正确`**、对口令 200 且拿到 `sciagent_admin` Cookie、退出后再次 401；`ui_admin` 新增 `gate_401 / wrong_pwd / login` 三条断言 |

## 第九轮：补齐官方 1.3.2 反向跳转 / 1.3.3.1 悬停翻译 / 1.3.3.2 译文导出（2026-11-11 22:20–22:55）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-53 | **P1** | 悬停正文里的 "Mistral 7B outperforms…"，浮层显示的却是 `arXiv:2310.06825v1 [cs.CL] 2023年10月10日`——译的是页边竖排水印，不是正在读的那句话。`elementFromPoint` 在正文词中心返回的是水印的 `.tw` span | PDF 里的竖排文字（arXiv 侧边水印、竖排书名）词框高度 166pt，是正常行高（~10pt）的十几倍，在透明文本层里是巨大的 span 且 DOM 靠后，`mouseenter` 先命中它 | `makeWord` 对 `h > 40pt` 的词加 `pointer-events: none`：这类文字没有阅读价值，让指针穿透到真正的正文词，不影响正文的选中与悬停 | 该页 2 个竖排词全部 `pointer-events:none`；悬停命中正文句 166 字符，译文 30 汉字 |
| D-54 | **P2** | 悬停作者行时，送进翻译的是「16 位作者 + Abstract + We introduce…」共 500+ 字符：一次要等 10 秒以上，译文对不上任何一句话 | 前端按词序断句只看 `. ? !`，而作者列表用逗号分隔、整段没有句号；只有 320 字符上限兜底，切在句子中间 | `buildSentences` 增加节标题边界（Abstract / Introduction / References / Appendix 等，且缓冲已有 30 字符才切）；上限从 320 收到 240 | 悬停作者行时按节标题切开，句子长度 ≤ 240；正文句仍是完整一句 |
| D-55 | **P1（能力缺失）** | 官方 1.3.2 要求「从 References 快速跳回原来的位置」，实际只有单向：正文 `[11]` → References。References 条目点开只能看文本，回不到引用它的正文 | 建索引时只做了「编号 → 条目位置」，没有反向的「编号 → 正文出现位置」；`Citation` 表存的是文献之间的引用边，不是正文角标位置 | 新增 `GET /documents/{id}/references/{n}/cites`：扫全文 chunk 的 `[n]` / `[1, 2]` / `[4-6]`（含 0 的组按数学区间丢弃），返回页码、bbox、整句与上下文；前端在条目浮层里列出「正文引用 N 处」，点一处 `jump` 回原文并携带 `focus` 做句级高亮 | 浮层显示「正文引用 1 处」；点回 p1 后 7 个逐行框、框高 15.97px vs 行高 15.82px、无近似框 |
| D-56 | **P1（能力缺失）** | 官方 1.3.3.1 写的是「鼠标划词**或者悬停**翻译」，实际只有划词。长句阅读时用户要先拖选、再点按钮，读一段打断两次 | 划词是 1.3.3.1 前半段的需求，实现时把「或悬停」当成了可选项 | 阅读器工具栏加「悬停译」开关（默认关、localStorage 记忆）；`mouseenter` 停 380ms 取所在整句调 `/api/translate`，浮层跟随光标并 1.2 秒后随鼠标移开消失；前端按句子缓存，二次悬停 406ms 内出结果；浮层 `pointer-events:none` 避免自我抖动 | 译文 30 汉字、浮层 340×97 在视口内、`pointer-events=none`、缓存命中 406ms、关掉开关后不再触发 |
| D-57 | **P1（能力缺失）** | 官方 1.3.3.2 要求整篇翻译有「输出可读性：Markdown 或 HTML」，实际只有双栏网页视图，没有可带走的译本文档；同时 1.3.3.2.c「代码和公式保留英文不翻译」也没做——公式块照样送去机翻 | 对照视图的产出直接落 `translations` 表供双栏渲染，从一开始就没设计「成篇输出」；`translate_pages` 只过滤了 `reference` | ① `keep_verbatim()`：`formula` 整块 + LaTeX 密度高/代码特征明显的段落，**原样写入译文表**（`model=verbatim`），三处（双栏 / 导出 / 统计）看到的内容一致；② `export_zh()` 从缓存拼 Markdown：标题、作者、覆盖率、按章节分节、公式与代码用围栏块原样保留、未译段落保留原文并附 HTML 注释说明；③ 新增预览与下载两个接口，前端「对照」工具栏加「导出中译」抽屉 | 41/43 段导出 16123 字符；公式文档 59 段原样保留、导出全文 56643 字符含 118 个围栏、`\begin`/`\frac` 原文保留；下载 200 |

## 第十轮：补齐官方 1.6.2 架构拓扑图 / 1.6.3 数据可视化与 Figure Caption（2026-11-11 23:00–23:35）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-58 | **P1（能力缺失）** | 官方 1.6.3 要求「表格、折线图、柱状图或三维雷达图 + 自动 Figure Caption」，实际只有 `mermaid` / `tikz` 两种柱状代码，前端**没有任何入口**，图注完全没有；官方 1.6.2 要求的架构拓扑图（TikZ / DOT / Mermaid / Matplotlib）**一行代码都没有** | 图表工具是早期作为「工具链演示」写的，只覆盖了硬性用例 C09 的最小要求（CSV→TikZ/Mermaid），没有按需求文档展开 | ① `chart.py` 扩到 **4 类 × 5 格式**（bar/line/radar/table × mermaid/tikz/matplotlib/latex/markdown），格式与类型不匹配时返回可用组合而不是 500；② 新增 `caption.py` 逻辑（在同文件内）：规则版（纯统计，断网可用）+ 模型版（qwen-flash 写中英双语图注与趋势）；③ 新增 `app/tools/topology.py`，模型只产出节点/边 JSON，代码层渲染四种格式；④ 新增 `POST /api/write/topology`；⑤ 写作视图拆成「论文框架 / 架构图 / 数据图表」三个 tab | 8 种图表组合全部出码；拓扑 7 节点 6 边，四种格式各含全部 7 个节点 id；`ui_write_viz` 五项全 PASS |
| D-59 | **P1（可信度）** | 图注第一次实测就把 BERT 的 BLEU **34.5 写成 35.2**——表格里根本没有这个数，是模型自己插值出来的。图注越漂亮，这种错越难被读者发现 | 提示词只给了每列的极值统计（峰值/谷值/首末变化），模型的"合理推断"没有原始数字可抄，只能自己算 | ① 提示词改为**把整张表逐格摊开**，并要求"每个数值必须与原始数据写法完全一致，不得四舍五入/插值"；② 新增 `check_numbers()`：把图注里出现的每个数字回查原表，命中原值/百分比/年份/型号编号之外的，列入 `foreign` 并在前端红框提示「请人工核对」 | 同一份 CSV 复测：22 个数字 **22/22 全命中**、`foreign` 为空；构造 `99.9` 假数字时 `foreign: ["99.9"]` 被抓出；`GPT-3` 的 `-3` 不会被误判 |
| D-60 | **P1（生成物不可用）** | 生成的 Matplotlib 脚本跑出来中文全是方框（`□□□`）；柱状图/架构图里箭头头部被节点方块盖住，看起来像"没有箭头"；雷达图 6 档径向刻度沿着一根轴挤成一串重叠数字；架构图固定 `figsize` 让 5 节点的层被压成一排 | ① `font.family` 只写 `serif`，系统 serif 无中文字形；② 箭头 `zorder=1` 低于方块 `zorder=2`；③ 极坐标默认每 1/6 一档且贴在 0° 轴上；④ 画布宽高写死 | ① 脚本内用 `fm.fontManager.ttflist` 探测可用中文字体，`font.family = ["Times New Roman", "DejaVu Serif"] + 可用中文`（西文 Times、中文回退）；② 箭头 `zorder=3`、文字 4/5；③ 径向刻度收到 3 档并 `set_rlabel_position(20)`；④ `figsize` 由坐标范围算，`min(9.5, span*0.62)` | 5 份生成脚本（架构图 + bar/line/radar）全部实跑成功产出 PDF；中文标题、图例、轴标签正常显示；箭头头部可见；雷达图刻度 3 档不重叠 |
| D-61 | **P2（预览失真）** | 架构图预览用 Mermaid 渲染时，7 节点图在写作视图（约 700px 宽）里被压成一根细竖柱，字号缩到 6px；改 `flowchart LR` 后横向展开但 SVG 仍被 `max-width` 缩到容器宽，字照样看不清；试过用 `A ~~~ B` 把同层节点锁成一行，结果 dagre 仍给不可见边分配 rank，柱子更细 | 写作视图只占中间一栏，左右分栏后每栏 340px；Mermaid 的 dagre 布局对"链式流水线"只能排出长条，且 svg 自适应宽度会把字号一起缩掉 | 预览放弃 Mermaid，改用 **ECharts 自绘分层图**（`layout:'none'` + 按 group 分行、行内均分的坐标）：宽度自适应、字号固定 12px、节点/边直接取自后端结构。Mermaid 代码仍作为四种交付格式之一保留 | 画布 936×426，画出节点数 = 数据节点数（7）、边数 = 6，与数据结构一一对应；预览无重叠；`ui_write_viz` 新增该断言防止"预览丢节点" |

## 第十一轮：本地模型实测与落地适配（2026-11-11 23:40–00:20）

测试在独立目录 `sciagent-localbench` 进行（40 组题 × 3 模型，脚本与原始数据一并归档到 `docs/local-bench/`），结论见 `docs/本地模型实测.md`。这一轮发现的不是产品缺陷，而是**"本地模型能不能用"这件事本身的坑**。

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-62 | **P1（能力失效）** | 把 `llm_route` 切到 `local` 后，划词翻译对**中译英和长句英译中直接失败**：等 9.15s / 9.66s 后返回"翻译服务暂时不可用"（三次重试的总和）。日志真实错误 `Ollama HTTP 500: prediction aborted, token repeat limit reached` | `_SYS_EN` 有 825 字符、7 条规则，云端模型无压力，但 qwen2.5:3b 处理不了，直接进入复读循环，被 Ollama 的中止机制打断。采样参数试了五种（repeat_penalty 1.15/1.3、repeat_last_n 256、num_predict 300/700）**全部复现**，换短提示词后 0.3s 正常 | `_translate_batch` 按 `gateway.route()` 选提示词：云端沿用原版，本地用 `_SYS_LITE`（87 字符）/ `_SYS_EN_LITE`（272 字符），保留核心约束（段数相等、术语统一、公式与角标原样、不留中文） | 本地路由下 4/4 用例通过：短英译中 0.68s、中译英 0.52s、长句英译中 0.84s、含公式句 0.57s；云端路由不受影响 |
| D-63 | **P2（笔误）** | `_SYS_EN` 里 `"Rules://n"` 把字面量 `//n` 喂给了模型，本该是换行 | 上一轮把 `\n` 写坏过一次（D-45），修的时候只改了同处、漏了这一行 | 改为 `"Rules:/n"` | 提示词已按行渲染，7 条规则独立成行 |
| D-64 | **P2（测试方法）** | 长文本组的 TTFT 一度测出 **159ms**（1300 token 输入），与"6GB 卡 prefill 不可能这么快"矛盾；照此画出的"长文本斜率"结论是反的 | 6 条长 prompt 共用同一前缀，Ollama 按最长公共前缀复用 KV cache，后 5 次的 prefill 被整段跳过；第一轮 953ms 才是真实值 | ① 每条材料加唯一头部 `【材料 N · 主题】`，打散缓存；② 另写 `prefill.py` 做**定长输出**（16 token）的纯 prefill 曲线，输入 414→5890 token；③ 报告里区分"总耗时"与"prefill 成本" | 本地 0.6 ms/token 线性上涨（414→642ms、5890→3600ms），云端 3k token 内恒定 ~430ms |

**已知局限（未修）**：含 `\text{log}` 的公式句，本地模型输出经 JSON 解析后 `\t` 被当成制表符，译文出现 `L = -	ext{log}`。云端模型输出同样内容时不命中。属"本地模型 + LaTeX 转义"边缘情况，已在报告第七节如实标注。

## 第十二轮：后台保活心跳（2026-11-12 01:00–01:20）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-65 | **P2（统计失真）** | 后台把参数改回原值后，「参数覆盖」仍显示 **1 项**、来源标成"后台覆盖"，效果与从未改过完全一样；`ui_admin.py` 的 `overridden == 0` 断言因此失败（`params 41 / rows 33` 都对，只有 load 项 false） | `save()` 无条件写 `app_settings` 行，只要经过一次"保存"就留下覆盖记录，哪怕值与启动值逐字节相同 | 保存时先与 `BOOT_VALUES`（启动快照）比对：相等就**删掉覆盖行**，只热更新内存值，返回 `reverted: true`；换成 `.env` 里不同的值仍照常落库 | 实测 `local → auto` 后 `overridden: 1 → 0`，`app_settings` 表清空，`ui_admin` 九项全 PASS |
| — | 新功能 | 无缺陷。冷启动 5876ms → 热态 138ms 的对照来自本轮实测，见 `01_test_cases.md` C14 | — | — | — |

## 第十三轮：主模型切 qwen-flash 的连带观察（2026-11-12 01:25）

| 编号 | 分级 | 问题（实测证据） | 根因 | 改法 | 回归结果 |
| --- | --- | --- | --- | --- | --- |
| D-66 | **P2（显示失真）** | 学术问答里的公式原样显示成 `$O(n^{2}·d)$`、`$d_k = d_v = d_{model}/h$`，带美元符号的源码。换 qwen-flash 后公式更密集，在演示截图里非常显眼（`evidence/qwen_main_qa.png`） | 前端 `index.html` 从未引入 KaTeX / MathJax（全仓 grep 无 `katex\|mathjax`），`mdToHtml` 只做 Markdown 转换 | **未修**。修法：引 KaTeX CDN + auto-render，只对消息区渲染、且只在流式结束后渲染一次（逐 token 重渲染会卡）。涉及 CDN 依赖与离线降级，需单独评估 | 现状记录在案；不影响引用与锚点校验（1.0 通过率） |
| D-67 | **P1（证据召回缺口）** | 问"多头注意力的计算复杂度是多少"时，检索到的 10 条证据里**没有 Table 1**，模型只能回答"证据未给出具体复杂度"。而库里 `1706.03762v1.pdf` 第 6 页的 chunk idx35（`kind=table`）确实存着 `Table 1: Maximum path lengths, per-layer complexity...` 和 `O(n2 · d)` | 表格 chunk 的文本被切碎成符号与列名，稠密向量接近噪声、BM25 也匹配不上中文"复杂度"→ 本地重排给的 `kind_bonus` 只有 1.05，云端重排同样没把它排进前 10 | **未修**。候选改法：① 表格 chunk 在重排时给更高先验（1.05 → 1.15）并保留整表不切；② 入库时为表格单独生成一句"这张表讲了什么"的文本描述，跟着 chunk 一起索引 | 已确认与模型无关：qwen-flash、DeepSeek 都答不出，但 DeepSeek 会明确指出"证据[5]只比较了 self-attention 与 recurrent，未给 multi-head"，属正确行为 |
